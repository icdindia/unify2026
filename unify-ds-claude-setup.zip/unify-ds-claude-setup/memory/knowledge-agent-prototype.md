---
name: knowledge-agent-prototype
description: "Where the Knowledge Agent artefact lives on the same Enterprise OS shell as Playbook Studio, and how the three ask kinds are wired"
metadata: 
  node_type: memory
  type: project
  originSessionId: f51f2c54-a39f-4694-8c66-97dee9f8080d
  modified: 2026-09-16T14:06:58.048Z
---

The ChargePoint Knowledge Agent (asked as a companion to the Playbook Studio clickthrough, spec: [https://claude.ai/artifact/WKjDRmH3ssF7bdL78oqEQF](https://claude.ai/artifact/WKjDRmH3ssF7bdL78oqEQF) — the artifact itself is served as a public reader and not readable by WebFetch) is `prototypes/knowledge-agent/` in Unify2026. Second of "two more artefacts on the same shell" that [[playbook-studio-design-decisions]] was written to guide; every type-size, spacing, colour, motion and geometry decision there is reused verbatim.

Dev server entry `knowledge-agent` on port 4178 in `.claude/launch.json`. `window.KnowledgeAgent` exposes `S`, `render`, `resetApp`, `beginAsk`, `answerPerm`, `ASKS`, `TICKETS`, `CLAUSES`, `CONCEPTS` — same driver-from-the-console pattern as Playbook Studio.

**Three ask kinds**, keyed on `ASK.kind`:
- `tickets` — user asks "show me my open tickets" / "what is on my desk"; source-pick is a single-row Jira permission card; artifact panel is the `plist / pdet` master-detail from playbook-studio.css re-used, feeding `TICKETS` with playbook positions per ticket.
- `clause` — "what is ChargePoint's take on the liability cap clause?"; source-pick is the SharePoint / OneDrive two-row `list-item` picker; artifact panel is a single scrolling `.ans` doc with top-line position, why-it-matters, settled-rows strip and the five-tier ladder.
- `concept` — "what auto-renewal terms do we accept?"; same SharePoint source-pick; artifact panel is `.ans` with a short answer, a by-contract-type `seg-table`, and the ladder.

Turn kinds are the same set as Playbook Studio minus the interview-specific ones (no `qprompt`, no `attachprompt`, no `attached`, no `drop`, no `summary`, no `sourcepick` with template selection). The finish sequence is identical: `startLearning → steps ticks (~620ms each) → finishLearning → citation card 'What I found' → agent pre-line → streamText closing → artifactPending 5000ms hold → replace with answer turn → 1200ms pause → set stage='answer' → panel slides in from the right on the same 520ms `cubic-bezier(.4,0,.2,1)`.

**Prototype-specific CSS** (only these live in `knowledge-agent.css`; everything above the "==== knowledge-agent deltas ====" marker is duplicated verbatim from `playbook-studio.css`):
- `.ask-grid` / `.ask-card` — landing-page ask tiles. Same shell as `.template-card` but with a bottom hint line and a right-hand tag pill.
- `.ans` / `.ans__scroll` / `.ans__col` / `.ans__section` / `.ans__h2` / `.ans__lead` / `.ans__body` — single-column answer doc (720 max width, `--spacing-3xl` between sections).
- `.settled` / `.settled__row` — "N of M — landed on X" strip for clause answers.
- `.seg-table` / `.seg-row` — three-column by-contract-type breakdown for concept answers.
- `.pcard__foot` / `.pcard__due` / `.pcard__num` — ticket-list card foot with pill + due-date (kept off the playbook ticket cards, restored here because the ticket queue has room for a metadata row).
- `.pdet__actions` — "Open in Jira" / "Draft response" button row at the bottom of a ticket detail.

**Verification workflow** identical to Playbook Studio: `./tools/verify.sh` (both raw-hex and un-tiered token checks pass; a 2px padding and a 16px line-height were the only two failures during the build and were rewritten to `--spacing-xxs` and `--text-xs-regular-line-height`). Browser-pane sanity checks pass — stage columns resolve to `440 0 rest`, bubble text stays at 13/20, nav auto-collapses on first entry into a chat, artifact panel slides in from the right.

**Why:** the user asked for the Knowledge Agent "basis the same UI decisions taken in the playbook artefact" and "use memory and skills from the local folder not to deviate at all." Reusing the shell/atoms without deviation is the whole point of the artefact.

**How to apply:** for the third and final artefact on this shell, copy this same skeleton — same CSS trunk, same turn kinds, same finish sequence — and swap only the data.js payload and the answer canvas composition. The delta CSS block at the bottom of `knowledge-agent.css` is the template for how to keep the deltas small and greppable.
