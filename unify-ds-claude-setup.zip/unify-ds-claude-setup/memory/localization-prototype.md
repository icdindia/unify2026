---
name: localization-prototype
description: "Localization screen rebuilt at prototypes/localization, port 4180, plus the two Figma traps that frame taught"
metadata: 
  node_type: memory
  type: project
  originSessionId: bda3c09b-0123-4926-8313-2fda12188a59
  modified: 2026-09-25T06:37:26.322Z
---

`prototypes/localization/` is a verbatim Figma→HTML rebuild of the **Localization**
screen — UnifyApps Platform (1)(2) 2026, file `jcbxvaNrZCWeQsIiZRta6F`, frame
`15119:614275` (1440×900). Launch config name `localization`, port 4180.
Standalone single file at `dist/localization.html`. Unlike
[[playbook-studio-prototype]] / [[knowledge-agent-prototype]] /
[[template-studio-prototype]] this one is not on the Enterprise Brain shell —
it is the **light `navbar-bg` platform rail**, a different component from both
`components/nav-rail` and `components/main-nav`.

Two things this frame proved that are easy to get wrong again:

- The desktop Dev Mode `get_design_context` could not resolve node ids from this
  file at all ("No node could be found"), while `get_metadata` on the same ids
  worked. The **remote plugin server** (`mcp__1b1904b4-…__get_design_context`,
  which takes a `fileKey`) resolved every node first try. Reach for it rather
  than stalling.
- Stroke alignment split inside one frame: the rule above NAMESPACES
  (`15127:648797`) is a real `border` (first child at y=9, padding 8) while every
  other stroke is free of layout, and two strokes — the Working area and the
  Secondary nav's right edge — composite **above** their children and so need an
  `::after` overlay, not an inset ring.

Full record in `shared/DRIFT-LOG.md §24` and `shared/MISSING-COMPONENTS.md`.
