---
name: access-picker-prototype
description: "Platform-wide team+people \"who can use this\" picker — components/audience-picker + prototypes/access-picker, port 4184, UX redesign of Figma section 8324:361899"
metadata:
  node_type: memory
  type: project
  originSessionId: 1cb75ced-7602-4107-9c51-b64acd2f031e
  modified: 2026-10-06T09:51:38.103Z
---

On 6 Oct 2026 the user asked to make "selecting teams and users" intuitive for the whole platform, using Figma section 8324:361899 in file IaiPcfy2gccS9V861ZFPuv (Enterprise Search › Features › Routines / Meetings), and to change bad UX rather than copy it. This is a UX redesign, not a verbatim rebuild like [[localization-prototype]].

- Reusable component: `components/audience-picker/audience-picker.{css,js}` → `window.AudiencePicker.create(el, {directory, value, feature, onChange})`, plus `.toast()`. No side panel — removed on 6 Oct 2026 at the user's request.
- Prototype: `prototypes/access-picker/` (launch config `access-picker`, port 4184, serves repo root → open `/prototypes/access-picker/`). `window.AccessProto` exposes `S`, `render`, `picker`, `setAccess`.
- Standalone: `python3 prototypes/access-picker/build.py` → `dist/access-picker.html`. JS-rendered icons go through `A(name)` + injected `window.AP_ASSETS`, because `tools/build-standalone.py` only inlines literal `<img src="…">` in the HTML.

UX decisions made (keep consistent if extended): wording is **"Teams and users" / "users" everywhere** (never "people"); one combined Teams-and-users field (frames had "Teams" + a mislabelled "Category*" users field); radio copy "Everyone in the workspace" / "Specific teams and users"; filter tabs All/Teams/Users/Selected(n); people covered by a selected team show muted-checked "via <Team>" and can't be double-added; teams expand to show members; selected rows pinned on open (snapshot, no jumping); paste emails to bulk-add; one-line field with clickable "+N" → Selected tab; reach summary "N users can use X · See all <selected count>", which opens the Selected tab (not a panel); **4px rule inside the dropdown** — every padding/gap/margin is a multiple of 4 (checked with a computed-style scan over all menu states); undo toast on every removal; choosing Specific with nothing selected auto-opens the picker; Publish validates. Routines' duplicate "Enable Routines" button replaced by one "is off" banner.

**Why:** the user wants this to be the platform pattern, not a one-off screen.
**How to apply:** reuse the component for any other access/audience setting; `./tools/verify.sh` needs one declaration per CSS line (its scanner is line-based); the frame's "clock" asset in 8324:353016 is actually the breadcrumb chevron — the real Routines clock is `routine-clock.svg` from 8324:352789.
