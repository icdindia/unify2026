---
name: playbook-studio-prototype
description: Where the Enterprise OS rebuild of the ChargePoint Playbook Studio clickthrough lives and how it is verified
metadata: 
  node_type: memory
  type: project
  originSessionId: f72207b8-cb59-4551-b2c0-185d5aa67a15
  modified: 2026-09-16T10:59:28.024Z
---

The ChargePoint Playbook Studio clickthrough (`playbook-studio-project/playbook-studio.html`, a self-contained Claude artifact) was rebuilt on 16 Sep 2026 as `prototypes/playbook-studio/` in Unify2026, using the Enterprise OS atoms (new: `button`, `es-breadcrumb`, `copilot-input`, `artifact-header`, `question-card`, `inline-artifact-card`, plus `main-nav--expanded`). Dev server entry `playbook-studio` on port 4177 in `.claude/launch.json`; `window.PlaybookStudio` exposes `S`, `render`, `pickType`, `answerPerm`, `chooseOption` for driving the flow from the browser pane. `S` itself is initialised in `data.js:956` — searching `app.js` alone will not find it.

Thread turns are keyed by `t.k`: `user`, `agent`, `perm`, `drop`, `sourcepick`, `attachprompt`, `attached`, `steps`, `findings`, `summary`, `artifact`, plus the motion / echo turns `stream` (word-by-word reveal via `streamText`), `artifactPending` (ring-loader artifact card via `pendingArtifactCard`), and `qprompt` (the just-answered question echoed back into the transcript above its user bubble — pushed in `chooseOption`). Interview completion path is `chooseOption → finishInterview → streamText(final line) → push artifactPending → 5000ms hold → replace with {k:'summary'} and set stage='playbook'` — the artifact panel slides in from the right via `.stage { transition: grid-template-columns 520ms cubic-bezier(.4,0,.2,1); }` plus a 520ms opacity + `translateX(100%) → 0` on `.artifact-panel` itself (ease-in-out, both in sync); `prefers-reduced-motion` disables all three.

**Why:** the user asked for the clickthrough recreated "in the enterprise OS components, spacing, colour and typographic decisions without deviation" — the artifact's own token block was the thing being replaced. The motion pass on 16 Sep 2026 was because "as soon as I answer last question prompt, this suddenly appears" — the summary and panel had been snapping in with no easing.

**How to apply:** edit the prototype, never the artifact; after edits rebuild the standalone `dist/playbook-studio.html` with `tools/build-standalone.py` — the linked index.html shows only a bare shell when opened via file:// (the user hit this); run `./tools/verify.sh` (spacing / radius px must map to a token or carry a `DRIFT` marker on the same line, type sizes must bind DS type tokens, `--colors-*` and `--spacing-*` names use the doubled-prefix form e.g. `--colors-utility-brand-utility-brand-500`) and measure with `getBoundingClientRect` in the browser pane before claiming anything. Two clickthrough departures (Spectral title, filled Publish) were reverted to the frame values and are logged in [[unify-drift-log]] §23.
