---
name: playbook-studio-design-decisions
description: "Every type-size, spacing, colour, motion and layout decision made while iterating the Playbook Studio prototype — reuse verbatim when building the next two artefacts on the same chat/artifact pattern"
metadata: 
  node_type: memory
  type: project
  originSessionId: f72207b8-cb59-4551-b2c0-185d5aa67a15
  modified: 2026-09-16T13:49:09.598Z
---

Decisions accumulated across ~30 iterations on `prototypes/playbook-studio/`. Every value here was either measured from Figma frames 875:165670, 905:300224, 905:301453, 905:300535, 905:300536 or explicitly requested by the user during those iterations. Copy them as the baseline for the next two artefacts on the same shell.

**Why:** the user asked for these to be remembered "as we have to make 2 more such artefacts" — the alternative is re-deriving them from screenshots, which is how they got wrong the first time.

**How to apply:** these are already in `prototypes/playbook-studio/playbook-studio.css` and `app.js`. For the next artefact, start from the same shell (nav-rail collapsed on enter, 760 message column, avatar in -28 gutter, artifact panel slide-in, etc.) and only diverge where the domain content genuinely needs different behaviour. See [[playbook-studio-prototype]] for the file layout and verify workflow.

## Type sizes (all globally applied so split ↔ full modes match)

| Element | Token | Reason |
|---|---|---|
| Bubble, richtext, qprompt, citation card q/a, question card title + options + free text | `text-sm-regular` (13/20) | User asked for -1px, DS scale steps 15 → 13; applied to BOTH full and split modes so switching between them doesn't jump |
| Question card evidence line | `text-xs-regular` (12/16) | Was 15px per atom, user explicitly asked for 12 |
| Citation card top / "What I found" / "How I arrived at this playbook" / "Your answers" | 13/20 | Reduced to match body |
| `.turn__cards` gap (between stacked cards) | `spacing-md` (8) | 8 apart, matches Figma citation-card / artifact-card stack |
| CoT internal | Untouched (atom's own text-xs / text-sm) | |

## Spacing / rhythm

| Gap | Value | Where |
|---|---|---|
| User bubble → agent turn | 40 | `.turn--user { padding-bottom: --spacing-5xl }` — matches Figma y=68→108 |
| Agent chunk → agent chunk (same response) | 12 | `.turn--agent { padding-bottom: --spacing-lg }` — matches Figma y=358→370 |
| Agent → user (qprompt → user answer) | 40 total | 8 (qprompt.pb) + 12 (turn-agent.pb — wait: was later bumped to 24 for pacing) + 12 (`.turn--agent + .turn--user { padding-top }`) + 8 (bubble.pt) |
| Full-mode inside-turn gap | `spacing-3xl` (24) | avatar → richtext → CoT → cards (+12 pacing bump from spacing-lg=12 baseline) |
| Split-mode inside-turn gap | `spacing-xl` (16) | `.stage[data-artifact="open"] .turn--agent { gap }` — +12 from spacing-xs=4 baseline, user asked to open up copilot panel |
| Split-mode chat col padding | `padding: 16 16 0 40` | left: `--spacing-5xl` reserves room for the -28 hanging avatar so it doesn't get clipped by stage's overflow:hidden |
| Question card option row | 36 total (4 top + 4 bottom padding) | `.question-card__option { padding-y: --spacing-xs }` — was 8+8=16, trimmed 8 |
| Question card free row | 28 total (6 top + 2 bottom) | `padding-top: --spacing-sm; padding-bottom: --spacing-xxs` |
| Question card Skip button | 24px explicit height | zero vertical padding, `height: 24px` |
| Source picker + attach-prompt cards | 75% width, max 570px | `.turn--agent[data-k="sourcepick"] .turn__cards { width: 75%; max-width: 570px }` — 3/4 of the 760 col |
| Template landing cards | No `__foot` — just tile + name + one-line description (metadata row removed) |
| Issue row (`.pcard`) | No `__foot` — no risk dot, no Template ref, no freq pill (metadata row removed) |
| Issue detail (`.pdet`) | No `__foot` — no "Negotiated in X of Y" line, no "Show approved language" toggle |
| Doc header | No horizontal-tabs (`All issues` / `Negotiation data` removed) — `tabAll` renders directly |

## Colours (all resolve to real tokens, not literals)

| Element | Token |
|---|---|
| Agent avatar (both `.turn__avatar` and `.cot__avatar`) | 1px stroke `--colors-utility-brand-utility-brand-400`, transparent bg, brand-400 icon color |
| Source-row Connect button (filled success) | bg `--colors-utility-success-utility-success-500`; label `--colors-text-text-white`; hover `--colors-utility-success-utility-success-600` |
| AI-suggest sparkle | `--colors-text-text-quaternary-500` at opacity 0.45; fade to opacity 1 on tier hover or button focus (160ms ease-out) |
| Pending artifact spinner (24px circle) | 2px border `--colors-border-border-secondary`; top border `--colors-utility-brand-utility-brand-500`; 900ms linear |
| History row (rail) | truncate one line, `overflow: hidden; white-space: nowrap; text-overflow: ellipsis` (overrides atom's `overflow-wrap: break-word` standing constraint) |

## Sizes / geometry

| Element | Size |
|---|---|
| Agent avatar chip (`.turn__avatar` and `.cot__avatar` alike) | 12 × 12, 1px stroke, 8 × 8 ai-avatar glyph inside |
| Source-picker row icons (`.list-item__icon` in sourcepick, `.drop__icon` in attachprompt) | 16 × 16 (override atom's 32; SVG at 16 × 16 with `position: static`) |
| Message column | 760 wide, centred, with the avatar hanging at `left: -28px` |
| Copilot panel (split mode) | 440 wide; chat col at 100% with 40px left padding for avatar gutter |
| Artifact panel | position: absolute; top/right/bottom: 0; left: 440 (open) or 0 (expanded) |
| Question card top bar | 48 tall, contains pagination (chevron-left 16 + "N of M" text-xs + chevron-right 16) + close 16 |
| Question card body option row | 36 tall |
| Question card body free row | 28 tall, Skip button 24 tall |

## Motion / timing (all with `prefers-reduced-motion: reduce` off-switch)

| Animation | Value |
|---|---|
| Artifact panel slide | `transform: translateX(100%) → 0` + `opacity: 0 → 1` over 520ms `cubic-bezier(.4, 0, .2, 1)` |
| Stage grid columns | 520ms `cubic-bezier(.4, 0, .2, 1)` — same curve so slide + column widening finish together |
| Nav rail width collapse | 340ms `cubic-bezier(.42, 0, .58, 1)` (CSS-spec ease-in-out) — overrides atom's 220ms out-only default |
| Stream text (finish-interview closing line) | 3 words per 55ms tick, 220ms startup, 260ms tail before pending card shows |
| Pending card (spinner) hold | 5000ms |
| After pending swap, before panel opens | 1200ms |
| Stream blink caret | 900ms `steps(2) infinite` |
| Pending spinner rotation | 900ms linear infinite |

## Behaviour / structure

- **Turn kinds** (`t.k`): `user | agent | perm | drop | sourcepick | attachprompt | attached | steps | findings | summary | artifact | stream | artifactPending | qprompt`. Plain agent kinds get an outer `.turn__avatar`; CoT-carrying kinds (steps/findings/summary) skip it — the CoT row's `.cot__avatar` supplies the same 12 × 12 glyph in the same coordinates.
- **`data-k` attribute** on the turn div for CSS targeting (`sourcepick`, `attachprompt`). Every kind that adds cards outside of a card grid should get a `data-k` if it needs custom width or icon overrides.
- **Source picker** renders as two `.list-item` atom instances (SharePoint + Attach files directly). Trailing Connect button lives outside `.list-item__content` inside the `.list-item` flex row. Do not re-invent `.srcopt`.
- **Nav rail auto-collapse**: `render()` checks `S.stage !== 'start' && !S._autoNavCollapsed` and flips rail `data-state` to `collapsed` on the first entry into a chat; `resetApp` clears the flag and re-expands the rail. Manual toggles via `#railToggle` are respected.
- **Finish sequence**: `chooseOption → finishInterview → streamText (3-word ticks) → push artifactPending → 5000ms hold → swap in summary (with citation card "How I arrived at this playbook") → 1200ms pause → set stage='playbook' → panel slides in`.
- **Summary card body rows** (`How I arrived at this playbook`): Read · Analyzed · Issues resolved · New issues folded in (only when >0) · Your calls (only when >0) · Positions set · Second-tier fallbacks (only when >0) · Parked as deferred (only when >0). Sentence-style values, no "executed" doubling — `t.corpus.label` already starts with "executed".
- **Question card** carries pagination `< N of M >` before the close × in the top bar; qPrev/qNext handlers wired to `S.qi--/++` + `renderDock()`.
- **Composer paperclip fallback**: no-op when `S.awaitFiles` is false — do NOT push canned "Attached: … / Read it …" pairs (that stub was removed after it duplicated across the thread).

## Brand mark (added 16 Sep 2026)

- Local file at `prototypes/playbook-studio/assets/unify-logo.svg`. Exported SVG had a 52 × 40 viewBox with ~20 px of whitespace around a ~30 × 30 mark; tighten to `viewBox="10.5 7 32 32"` so the visible glyph fills the rail slot without shrinking.
- Rendered via `setHTML(#brandMark, '<img src="./assets/unify-logo.svg" class="brand-mark-img">')` — atom's inline `unify-logo` is bypassed.
- Sized at 36 × 36 in this prototype (bumped from the atom's default 32). Override on `.main-nav__x-logo { width: 36px }` and `.main-nav__x-logo .brand-mark-img { display: block; width: 36px; height: 36px; object-fit: contain }`.
- Wordmark still uses the atom's inline `unify-wordmark-gold` icon; the user's exported wordmark SVG at `~/Downloads/unify wordmark.svg` was mislabeled as a plus icon. When a real wordmark arrives, swap the second `setHTML` symmetrically.

## Buttons

- **Publish Playbook** in the artifact header — `.btn--xs .btn--brand-primary` (filled brand, primary affordance).
- **Add from Library** in the artifact header — `.btn--xs .btn--neutral-secondary` (outlined, secondary affordance).
- **Connect** buttons on source rows in the sourcepick — filled success (`bg: --colors-utility-success-utility-success-500`, hover `-600`, label `--colors-text-text-white`).
- Only ONE primary/brand button per surface; multiple filled buttons compete.

## Verification workflow

- `./tools/verify.sh` after every CSS/JS edit; all font-sizes must bind DS type tokens, all spacing/radius px must map to a token or carry `DRIFT` on the same line.
- Local overrides go in `prototypes/playbook-studio/playbook-studio.css`; don't edit `components/*.css` atoms for prototype-specific tweaks (they're shared with other prototypes).
- `index.html` carries `?v=NN` query strings on the three script tags; bump on every change so browser cache picks it up.
- When JS state gets weird via console-driven testing, `window.PlaybookStudio.resetApp()` returns to the landing page cleanly.
