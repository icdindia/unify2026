# Unify DS + Claude + Figma setup bundle

- unify-ds-claude-figma-setup.md — how everything is wired
- whats-new-panel-setup.md — the What's new panel build
- skills/ — unify-enterprise-os (project skill), figma-use, figma-generate-design, figma-generate-library
- rulebooks/ — FIGMA-TO-HTML, HTML-TO-FIGMA, DRIFT-LOG, MISSING-COMPONENTS
- memory/ — Claude memory notes for this workspace

Install: copy skills/unify-enterprise-os to <repo>/.claude/skills/; copy the figma-* skills to ~/.claude/skills/ (or install the Figma plugin); put the rulebooks at the repo root (DRIFT-LOG and MISSING-COMPONENTS in shared/).
